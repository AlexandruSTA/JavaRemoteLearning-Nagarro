package com.iquestgroup.plant.reorg.exception;

public class UnqualifiedEmployeeException extends RuntimeException {

    public UnqualifiedEmployeeException(String message) {
        super(message);
    }
    
}
