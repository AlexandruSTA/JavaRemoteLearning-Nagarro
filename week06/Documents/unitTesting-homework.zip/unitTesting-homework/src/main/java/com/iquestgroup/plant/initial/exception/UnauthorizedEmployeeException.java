package com.iquestgroup.plant.initial.exception;

public class UnauthorizedEmployeeException extends RuntimeException {

    public UnauthorizedEmployeeException(String message) {
        super(message);
    }
    
}
