package com.iquestgroup.plant.reorg.exception;

public class UnauthorizedEmployeeException extends RuntimeException {

    public UnauthorizedEmployeeException(String message) {
        super(message);
    }
    
}
