package com.iquestgroup.bank;

import static org.junit.jupiter.api.Assertions.*;

public class AccountTest {
}
