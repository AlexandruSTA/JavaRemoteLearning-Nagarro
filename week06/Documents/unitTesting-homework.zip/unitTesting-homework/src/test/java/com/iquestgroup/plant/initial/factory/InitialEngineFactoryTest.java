package com.iquestgroup.plant.initial.factory;

import static org.junit.jupiter.api.Assertions.*;

public class InitialEngineFactoryTest {

}