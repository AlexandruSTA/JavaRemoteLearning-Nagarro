package com.iquestgroup.plant.reorg.factory;

import static org.junit.jupiter.api.Assertions.*;

public class ReOrgEngineFactoryTest {

}