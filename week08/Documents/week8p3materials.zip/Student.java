import java.util.Date;

public class Student {

    private int id;
    private String fistName;
    private String lastName;
    private Date dateOfBirth;
    private boolean graduated;
    private Address address;
}
