public class Address {

    private String city;
    private String zipcode;
    private String addressLine;
}
